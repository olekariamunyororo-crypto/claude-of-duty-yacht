export function initSentry(): void {
  // Sentry SDK init stub
}
