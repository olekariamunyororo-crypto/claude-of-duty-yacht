import React, { Component, type ReactNode } from 'react';
import { View, Text, StyleSheet } from 'react-native';

export class ErrorBoundary extends Component<{ children: ReactNode }, { hasError: boolean }> {
  state = { hasError: false };
  static getDerivedStateFromError() { return { hasError: true }; }
  render() {
    if (this.state.hasError) {
      return (
        <View style={styles.err}>
          <Text style={styles.txt}>A fatal render error occurred.</Text>
        </View>
      );
    }
    return this.props.children;
  }
}
const styles = StyleSheet.create({
  err: { flex: 1, backgroundColor: '#05080d', alignItems: 'center', justifyContent: 'center' },
  txt: { color: '#ef4444', fontWeight: 'bold' },
});
