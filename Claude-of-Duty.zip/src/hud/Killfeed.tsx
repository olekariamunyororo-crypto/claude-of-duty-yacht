import { View, Text, StyleSheet } from 'react-native';
import { useGameStore } from '../game/store/gameStore';

export function Killfeed() {
  const feed = useGameStore((s) => s.killfeed);
  return (
    <View pointerEvents="none" style={styles.box}>
      {feed.map((k) => (
        <Text key={k.id} style={styles.line}>
          <Text style={{ color: '#38bdf8' }}>{k.killer}</Text>
          <Text style={{ color: '#94a3b8' }}> [{k.weapon}] </Text>
          <Text style={{ color: '#f87171' }}>{k.victim}</Text>
        </Text>
      ))}
    </View>
  );
}
const styles = StyleSheet.create({
  box: { position: 'absolute', top: 16, right: 16, alignItems: 'flex-end' },
  line: { fontSize: 11, fontWeight: 'bold', marginBottom: 2, backgroundColor: 'rgba(0,0,0,0.5)', paddingHorizontal: 6, paddingVertical: 2, borderRadius: 4 },
});
