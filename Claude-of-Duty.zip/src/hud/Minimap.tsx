import { View, StyleSheet, Text } from 'react-native';
export function Minimap() {
  return (
    <View style={styles.map}>
      <Text style={styles.txt}>RADAR</Text>
    </View>
  );
}
const styles = StyleSheet.create({
  map: { width: 76, height: 76, borderRadius: 38, borderWidth: 1, borderColor: 'rgba(34,211,238,0.4)', backgroundColor: 'rgba(5,8,13,0.6)', alignItems: 'center', justifyContent: 'center' },
  txt: { color: '#38bdf8', fontSize: 9, fontWeight: 'bold' },
});
