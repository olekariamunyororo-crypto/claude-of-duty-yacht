export function HitMarker() { return null; }
