import { View, StyleSheet } from 'react-native';
import { world } from '../game/world';
export function HealthBar() {
  const pct = Math.max(0, Math.min(1, world.player.hp / world.player.maxHp));
  return (
    <View style={styles.bar}>
      <View style={[styles.fill, { width: `${pct * 100}%` }]} />
    </View>
  );
}
const styles = StyleSheet.create({
  bar: { width: 140, height: 8, backgroundColor: 'rgba(0,0,0,0.5)', borderRadius: 4, overflow: 'hidden' },
  fill: { height: '100%', backgroundColor: '#22c55e' },
});
