import { View, StyleSheet } from 'react-native';
import { Crosshair } from './Crosshair';
import { Minimap } from './Minimap';
import { AmmoCounter } from './AmmoCounter';
import { HealthBar } from './HealthBar';

export function HudCanvas() {
  return (
    <View pointerEvents="none" style={StyleSheet.absoluteFill}>
      <Crosshair />
      <View style={{ position: 'absolute', top: 16, left: 16 }}>
        <Minimap />
      </View>
      <View style={{ position: 'absolute', bottom: 20, left: 20 }}>
        <HealthBar />
      </View>
      <View style={{ position: 'absolute', bottom: 20, right: 120 }}>
        <AmmoCounter />
      </View>
    </View>
  );
}
