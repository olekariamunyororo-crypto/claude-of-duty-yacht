export function DamageIndicator() { return null; }
