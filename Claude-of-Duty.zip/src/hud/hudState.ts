export const hud = {
  hp: 100, maxHp: 100,
  mag: 30, reserve: 120,
  grenades: 2,
  reloading: false, reloadProgress: 0,
  score: 0, leaderScore: 0,
  alive: true,
};
